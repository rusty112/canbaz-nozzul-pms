export const SHIPS = [
    { id: "v1", n: "ORCUN C" }, { id: "v2", n: "BEHCET C" }, { id: "v3", n: "ATA" },
    { id: "v4", n: "SAADET C" }, { id: "v5", n: "NAZMI C" }, { id: "v6", n: "OBAHAN C" },
];
